var app = angular.module('myApp', ['ui.router']);

/*function setup() {
    document.write('<script type="text/javascript" src="calendarMonth/controller/myController.js" ></script>');
}
setup();*/


app.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider
        
        .state('home', {
            url: '/home',
            templateUrl: 'calendarMonth/calendar-directive.html',
            controller: 'myController'
        })
        
        .state('resultPage', {
            url: '/resultPage',
            templateUrl: 'resultConfirmedSeat/confirmedTicketPage.html',
            controller: 'resultController'
        })
    
});
