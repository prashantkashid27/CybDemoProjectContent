app.controller("myController", function($scope, $http, $state, $log, sharedProperties, CalendarAvailabilityData){

    var dayOfWeek = moment().startOf('month').day();
    var daysInMonth = moment().daysInMonth();
    $scope.currentDate = moment().format("DD");
    $scope.currentMonth = moment().format("MMMM");
    $scope.currentYear = moment().format("YYYY");
    $scope.todaysDate = moment().format("MM-DD-YYYY");
    
    $scope.weeks = []; 
    
    $scope.nextMonth = moment().format("MM-DD-YYYY");
    $scope.prevMonth = moment().format("MM-DD-YYYY");
    
    var flag = false;  
    
    var date = moment().startOf('month').format("MM-DD-YYYY");
    var status = "";
    var isDisabled = false; 
    
    if(sharedProperties.getDates()){
        $scope.dateRange = sharedProperties.getDates();   
        $scope.dateRangeObject = sharedProperties.getDatesObj();
    }
    else{
        $scope.dateRange = {
            checkedInDate : "",
            checkedOutDate : ""
        }
        $scope.dateRangeObject = {
            checkedInDateObj : {},
            checkedOutDateObj : {}
        }
    }

    
     /* to get the json data*/
    
    /*$http.get("http://localhost:3000/data/data.json")
    .then(function mySucces(response) {
        
        $scope.monthsData = response.data;
        console.log($scope.monthsData);
        $scope.createMonth();
        console.log(response.data.months[0].dates[5].isAvailable);
    
    }, function myError(response) {
        $scope.myWelcome = response.statusText;
        console.log(response.statusText);
    });*/
    
    $scope.createMonth = function(){
        var startDate = 1;
        var digit = 1;
        //status = "";
        isDisabled = false; 
        
        var k = 0;
        console.log($scope.monthsData);
        console.log($scope.currentMonth);
        while($scope.currentMonth != $scope.monthsData.months[k].name){
            k++;
        }
        console.log(k);
        console.log($scope.monthsData.months[k].dates.length);
        
        for(var i=0;i<6;i++) {
            var eachWeek = [];
            
            for(var j=0;j<7;j++) {
                if(dayOfWeek > j && i == 0){
                    eachWeek[j] = { 
                        "digit" : "",
                        "date" : "",
                        "status" : "",
                        "isDisabled" : true,
                        "isStartDate" : false,
                        "isEndDate" : false
                    }
                }
                else{
                    if(digit <= daysInMonth){
                        if(date == $scope.todaysDate){
                            status = "Today";
                        }
                        
                        if(moment($scope.todaysDate).isAfter(moment(date))){
                            isDisabled = true;
                        }
                        
                        for(var l=0;l<$scope.monthsData.months[k].dates.length;l++){
                            if(date == $scope.monthsData.months[k].dates[l].date){
                                isDisabled = true;
                            }
                        }
                        
                        eachWeek[j] = {
                            "digit" : digit++,
                            "date" : date,
                            "status" : status,
                            "isDisabled" : isDisabled,
                            "isStartDate" : false,
                            "isEndDate" : false
                        };
                        
                        if(date == $scope.dateRange.checkedInDate){
                            console.log("in checkd in date startDate and status");
                            eachWeek[j].isStartDate = true;
                            eachWeek[j].status = "startDate";
                            $scope.dateRange.checkedInDate = eachWeek[j].date;
                        }
                        if(date == $scope.dateRange.checkedOutDate){
                            console.log("in checkd out date EndDate and status");
                            eachWeek[j].isEndDate = true;
                            eachWeek[j].status = "EndDate";
                            $scope.dateRange.checkedOutDate = eachWeek[j].date;
                        }
                        
                        status = "";
                        isDisabled = false;
                        date = moment(date, "MM-DD-YYYY").add(1, 'day').format("MM-DD-YYYY");
                        
                    }
                }
            }
            $scope.weeks.push(eachWeek);
            console.log("weeks"+$scope.weeks[0][0].isDisabled);
        }
        console.log($scope.weeks);
    };
    
    $scope.getCalendarAvailabilityData = function() {
        var promise = CalendarAvailabilityData.getCalendarData();
        promise.then(function(response) {
            
            $scope.monthsData = response.data;
            console.log($scope.monthsData);
            console.log(response.data);
            $scope.createMonth();
        },
        function(error) {
            $log.error('failure loading calendarData', error);
        });
    };
  
    $scope.getCalendarAvailabilityData();
    
    
    $scope.getMonth = function(whichMonth){
    
        $scope.weeks = [];
        
        if(whichMonth == 'next'){
            $scope.nextMonth = moment($scope.nextMonth, "MM-DD-YYYY").add(1, 'month').format("MM-DD-YYYY");
            $scope.currentMonth = moment($scope.nextMonth, "MM-DD-YYYY").format("MMMM");
            $scope.currentYear = moment($scope.nextMonth, "MM-DD-YYYY").format("YYYY");
            
            $scope.prevMonth = $scope.nextMonth;
            
            dayOfWeek = moment($scope.nextMonth, "MM-DD-YYYY").startOf('month').day();
            daysInMonth = moment($scope.nextMonth, "MM-DD-YYYY").daysInMonth();
            
        }
        else if(whichMonth == 'prev'){
            
            $scope.prevMonth = moment($scope.prevMonth, "MM-DD-YYYY").subtract(1, 'month').format("MM-DD-YYYY");
            $scope.currentMonth = moment($scope.prevMonth, "MM-DD-YYYY").format("MMMM");
            $scope.currentYear = moment($scope.prevMonth, "MM-DD-YYYY").format("YYYY");
            
            $scope.nextMonth = $scope.prevMonth;
            
            dayOfWeek = moment($scope.prevMonth, "MM-DD-YYYY").startOf('month').day();
            daysInMonth = moment($scope.prevMonth, "MM-DD-YYYY").daysInMonth();
            
            date = moment(date, "MM-DD-YYYY").subtract(2, 'month').format("MM-DD-YYYY");
            
        }
        
        $scope.createMonth();
    
    }  

    $scope.compareCheckInOut = function(date){
        console.log("date = ==== =="+date);
        console.log(moment(date).format("MM"));
        console.log(moment($scope.weeks[1][1].date).format("MM"));
        
        if(moment(date).format("MM") != moment($scope.weeks[1][1].date).format("MM")){
            
            $scope.dateRangeObject.checkedOutDateObj.isStartDate = false;
            $scope.dateRangeObject.checkedOutDateObj.status = "";
            
            $scope.dateRangeObject.checkedInDateObj.isEndDate = false;
            $scope.dateRangeObject.checkedInDateObj.status = "";
            
            return true;
            
        }
        else{
        
            for(var i=0;i<6;i++) {
                for(var j=0;j<7;j++) {
                    if($scope.weeks[i][j].date == date){
                        console.log($scope.weeks[i][j]);   
                        return $scope.weeks[i][j];
                    }
                }
            }
        }
    }
    
    $scope.reserveSeat = function(event, selectedDate, selectedDateObj){
     
        console.log("clicked");
        console.log(event);
        console.log(selectedDate);
         
        if(flag == false){
            
            console.log("***************")
            console.log($scope.weeks[0][0]);
            
            selectedDateObj.isStartDate = true;
            selectedDateObj.status = "startDate";
            
            /*  if clicked on same date---
            */
            if($scope.dateRange.checkedInDate == selectedDate){
                if($scope.dateRange.checkedOutDate != ""){
                    $scope.dateRange.checkedInDate = "";
                    $scope.dateRangeObject.checkedInDateObj.isStartDate = false;
                    $scope.dateRangeObject.checkedOutDateObj.isEndDate = false;
                    
                    
                    if($scope.compareCheckInOut($scope.dateRange.checkedInDate) == true){
                           $scope.compareCheckInOut($scope.dateRange.checkedInDate);
                    }
                    else{
                        //get the Object of checkout date
                    var checkDateObj = $scope.compareCheckInOut($scope.dateRange.checkedOutDate);
                    
                    console.log("resetted all dates");
                    selectedDateObj.isStartDate = false;
                    selectedDateObj.status = "";  
                    checkDateObj.isEndDate = false;
                    checkDateObj.status = "";
                    }
                    
                }
                else{
                    $scope.dateRange.checkedInDate = selectedDate;
                    selectedDateObj.isStartDate = true;
                    selectedDateObj.status = "startDate";

                }
                
            }
            else{
                    if($scope.dateRange.checkedInDate != ""){
                        //for check in date---clear properties
                        if($scope.compareCheckInOut($scope.dateRange.checkedInDate) == true){
                           $scope.compareCheckInOut($scope.dateRange.checkedInDate);
                        }
                        else{
                            var checkDateObj = $scope.compareCheckInOut($scope.dateRange.checkedInDate);

                            console.log("undefined given 1 ");
                            //get the Object of checkIn date and clear all values
                            checkDateObj.isStartDate = false;
                            console.log("undefined given 2 ");
                            checkDateObj.status = "";
                        }
                        

                    }

                    if($scope.dateRange.checkedOutDate != ""){
                        if($scope.compareCheckInOut($scope.dateRange.checkedOutDate) == true){
                            $scope.compareCheckInOut($scope.dateRange.checkedOutDate)
                        }
                        else{
                            //for check out date---clear properties
                            var checkDateObj = $scope.compareCheckInOut($scope.dateRange.checkedOutDate);

                            //get the Object of checkIn date and clear all values
                            checkDateObj.isEndDate = false;
                            checkDateObj.status = "";
                        }
                        

                    }
                
                if($scope.dateRange.checkedOutDate == selectedDate){
                    $scope.dateRangeObject.checkedOutDateObj.isStartDate = true;
                    $scope.dateRangeObject.checkedOutDateObj.status = "startDate";
                }
                else{
                    
                    $scope.dateRangeObject.checkedOutDateObj.isEndDate = false;
                    $scope.dateRangeObject.checkedOutDateObj.status = "";
                }
                
                console.log("check in date");
                $scope.dateRange.checkedInDate = selectedDate;
                $scope.dateRangeObject.checkedInDateObj = selectedDateObj;
                $scope.dateRangeObject.checkedInDateObj.status = "startDate";
                $scope.dateRange.checkedOutDate = "";
                flag = true;
                
                
            }
            
        }
        
        else{
            if($scope.dateRange.checkedInDate == selectedDate){
                
                //deselect startDate........
                selectedDateObj.isStartDate = false;
                selectedDateObj.status = "";
                flag = false;
                $scope.dateRange.checkedInDate = "";
                $scope.dateRange.checkedOutDate = "";
                

            }
            else{
                if(moment($scope.dateRange.checkedInDate).isAfter(selectedDate)){
                
                    if($scope.compareCheckInOut($scope.dateRange.checkedInDate) == true){
                           $scope.compareCheckInOut($scope.dateRange.checkedInDate);
                    }
                    else{
                        var checkDateObj = $scope.compareCheckInOut($scope.dateRange.checkedInDate);
                    
                        //get the Object of checkIn date and clear all values
                        checkDateObj.isStartDate = false;
                        checkDateObj.status = "";


                        $scope.dateRange.checkedInDate = selectedDate;
                        $scope.dateRange.checkedOutDate = "";
                        selectedDateObj.isStartDate = true;
                        selectedDateObj.status = "startDate";
                    }
                    console.log("check IN date");
                    flag = true;

                }
                else{
                    selectedDateObj.isEndDate = true;
                    selectedDateObj.status = "EndDate";

                    console.log("check out date");

                    $scope.dateRange.checkedOutDate = selectedDate;
                    $scope.dateRangeObject.checkedOutDateObj = selectedDateObj;
                    flag = false;

                }
            }
          
            
            
        }
        
    }
    
    $scope.confirmDates = function(){
        
        sharedProperties.addDate($scope.dateRange);
        sharedProperties.addDateObj($scope.dateRangeObject);
        
        $state.go('resultPage');
    }
    
    $scope.dateInBtwn = function(date){
        if((moment($scope.dateRange.checkedInDate).isBefore(date)) 
            &&
            (moment($scope.dateRange.checkedOutDate).isAfter(date))){
                return true;
            }
    }
    
});
