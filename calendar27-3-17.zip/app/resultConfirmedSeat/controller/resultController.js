app.controller("resultController", function($scope, $http, $state, sharedProperties){
    
    $scope.selectedDates = sharedProperties.getDates();
    console.log($scope.selectedDates.checkedInDate);
    console.log($scope.selectedDates.checkedOutDate);
    
    
    
});


