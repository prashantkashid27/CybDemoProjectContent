app.factory('CalendarAvailabilityData',["$q","$http", function($q,$http){
       
    /*var obj = {};
    
    obj.deferred = $q.defer();
    
    obj.fun = function(){
        
    
        $http.get("http://localhost:3000/data/data.json")
        .then(function mySucces(response) {
            obj.deferred.resolve(response.data);
        }, function myError(response) {
            obj.deferred.reject(response.data);
        });

        console.log(obj.deferred.promise);
        return obj.deferred.promise;
        
    }
    
    return obj;
    */
    
    return {
        getCalendarData: function() {
            return $http.get("http://localhost:3000/data/data.json");
        }
    }
    
}]);

