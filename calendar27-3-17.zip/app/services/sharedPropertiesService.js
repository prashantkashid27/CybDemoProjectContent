app.service('sharedProperties', function () {
        var selectedDatesList = "";
        var selectedDatesListObj = "";
            
        this.addDate = function(newObj) {
            selectedDatesList = newObj;
        };
    
        this.addDateObj = function(newObj) {
            selectedDatesListObj = newObj;
        };

        this.getDates = function(){
            return selectedDatesList;
        };
    
        this.getDatesObj = function(){
            return selectedDatesListObj;
        };
});