var express = require("express");
var app     = express();

var appDir = "/app";

app.use("/assets/css", express.static(__dirname+ appDir + "/assets/css"));
app.use("/assets/images", express.static(__dirname+ appDir + "/assets/images"));
app.use("/", express.static(__dirname + appDir));
app.use("/calendarMonth/controller", express.static(__dirname + appDir + "/calendarMonth/controller"));
app.use("/calendarMonth/directive", express.static(__dirname + appDir + "/calendarMonth/directive"));
app.use("/calendarMonth",express.static(__dirname + appDir + "/calendarMonth"));
app.use("/resultConfirmedSeat",express.static(__dirname + appDir + "/resultConfirmedSeat"));
app.use("/resultConfirmedSeat/controller",express.static(__dirname + appDir + "/resultConfirmedSeat/controller"));
app.use("/services",express.static(__dirname + appDir + "/services"));




app.get('/',function(req,res){
  res.sendFile('./app/index.html', {"root": __dirname});
  //It will find and locate index.html from View or Scripts
});

app.listen(3000);

console.log("Running at Port 3000");